import { Route, Switch } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import IdVerification from "@/pages/IdVerification";
import Learn from "@/pages/Learn";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useState, useEffect, useRef } from "react";
import ParticleBackground from "@/components/ParticleBackground";
import { Shield, Lock, Database, Zap } from "lucide-react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/verify" component={IdVerification} />
      <Route path="/learn" component={Learn} />
      <Route component={NotFound} />
    </Switch>
  );
}

// Cybersecurity-themed animated decorative elements
const CyberElements = () => {
  return (
    <>
      {/* Binary code rain effect */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-0 opacity-10">
        {Array.from({ length: 20 }).map((_, index) => (
          <div 
            key={index}
            className="absolute text-[8px] font-mono text-[#00FF8D] animate-float"
            style={{ 
              top: Math.random() * 100 + '%', 
              left: Math.random() * 100 + '%',
              animationDelay: Math.random() * 5 + 's',
              animationDuration: Math.random() * 10 + 5 + 's'
            }}
          >
            {Array.from({ length: 10 }).map(() => Math.round(Math.random())).join('')}
          </div>
        ))}
      </div>

      {/* Decorative elements in corners */}
      <div className="fixed top-0 left-0 w-24 h-24 pointer-events-none z-0">
        <div className="absolute top-0 left-0 w-full h-full border-t-2 border-l-2 border-[#0066FF] opacity-40"></div>
        <div className="absolute top-0 left-0 w-3 h-3 bg-[#0066FF] opacity-70"></div>
      </div>
      
      <div className="fixed top-0 right-0 w-24 h-24 pointer-events-none z-0">
        <div className="absolute top-0 right-0 w-full h-full border-t-2 border-r-2 border-[#0066FF] opacity-40"></div>
        <div className="absolute top-0 right-0 w-3 h-3 bg-[#00FF8D] opacity-70"></div>
      </div>
      
      <div className="fixed bottom-0 left-0 w-24 h-24 pointer-events-none z-0">
        <div className="absolute bottom-0 left-0 w-full h-full border-b-2 border-l-2 border-[#00FF8D] opacity-40"></div>
        <div className="absolute bottom-0 left-0 w-3 h-3 bg-[#00FF8D] opacity-70"></div>
      </div>
      
      <div className="fixed bottom-0 right-0 w-24 h-24 pointer-events-none z-0">
        <div className="absolute bottom-0 right-0 w-full h-full border-b-2 border-r-2 border-[#0066FF] opacity-40"></div>
        <div className="absolute bottom-0 right-0 w-3 h-3 bg-[#0066FF] opacity-70"></div>
      </div>
      
      {/* Scan line effect */}
      <div className="fixed top-0 left-0 w-full h-full pointer-events-none z-0 overflow-hidden">
        <div className="scanline"></div>
      </div>
    </>
  );
};

// Floating security icons
const SecurityIcons = () => {
  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {[
        { Icon: Shield, color: "#0066FF", size: 24, top: "15%", left: "5%" },
        { Icon: Lock, color: "#00FF8D", size: 20, top: "30%", right: "8%" },
        { Icon: Database, color: "#0066FF", size: 16, bottom: "25%", left: "10%" },
        { Icon: Zap, color: "#00FF8D", size: 18, bottom: "20%", right: "12%" },
      ].map((item, index) => (
        <div
          key={index}
          className="absolute animate-float opacity-20"
          style={{
            top: item.top,
            left: item.left,
            right: item.right,
            bottom: item.bottom,
            animationDelay: `${index * 0.5}s`,
          }}
        >
          <item.Icon size={item.size} color={item.color} />
        </div>
      ))}
    </div>
  );
};

function App() {
  // Ref for the main content area
  const contentRef = useRef<HTMLDivElement>(null);
  
  // Scroll to top button visibility
  const [showScrollTop, setShowScrollTop] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex flex-col text-white font-inter relative overflow-x-hidden circuits-pattern">
        {/* Decorative elements */}
        <CyberElements />
        <SecurityIcons />
        <ParticleBackground />
        
        {/* Overlay gradient for better text visibility */}
        <div className="fixed inset-0 bg-gradient-to-b from-[#0d0d20]/50 to-[#121222]/50 pointer-events-none z-0"></div>
        
        {/* Main content */}
        <div className="relative z-10">
          <div className="bg-[#0066FF]/5 border-b border-[#0066FF]/20">
            <div className="container mx-auto px-4 py-1 text-xs text-center md:text-right flex flex-col md:flex-row justify-between items-center">
              <div className="hidden md:flex items-center space-x-2">
                <span className="inline-block w-2 h-2 rounded-full bg-[#00FF8D] animate-pulse"></span>
                <span className="text-[#00FF8D] font-mono">SYSTEM ONLINE</span>
              </div>
              <div className="flex items-center justify-center md:justify-end space-x-4 w-full md:w-auto">
                <div className="flex items-center">
                  <Shield className="w-3 h-3 mr-1 text-[#0066FF]" />
                  <span>Security Level: <span className="text-[#00FF8D]">HIGH</span></span>
                </div>
                <div className="font-mono digital-counter">
                  ID: #
                </div>
              </div>
            </div>
          </div>
          
          <Navbar />
          
          <main ref={contentRef} className="flex-grow">
            <Router />
          </main>
          
          <Footer />
        </div>
        
        {/* Scroll to top button */}
        {showScrollTop && (
          <button 
            onClick={scrollToTop}
            className="fixed bottom-6 right-6 z-50 p-2 rounded-full bg-[#0066FF]/80 hover:bg-[#0066FF] shadow-lg transition-all hover:scale-110"
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-5 w-5" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
            </svg>
          </button>
        )}
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
