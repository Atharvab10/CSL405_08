export const CYBERSECURITY_THEME = {
  colors: {
    neonBlue: '#0066FF',
    neonGreen: '#00FF8D',
    neonPink: '#FF00AA',
    darkBg: '#121212',
    darkSurface: '#1E1E1E',
    offWhite: '#FAFAFA'
  },
  fonts: {
    orbitron: "'Orbitron', sans-serif",
    inter: "'Inter', sans-serif"
  }
};

export const ID_VERIFICATION_TIPS = [
  "Always check for holographic elements on IDs",
  "Examine the quality of printing and fonts",
  "Check for microprinting that requires magnification to read",
  "Verify that the ID has appropriate UV features",
  "Ensure the photo matches the person presenting the ID",
  "Check for proper lamination and card material"
];

export const SECURITY_FEATURES = [
  {
    name: "Holographic Overlays",
    description: "Holographic elements that change appearance when tilted"
  },
  {
    name: "Microprinting",
    description: "Tiny text that appears as a solid line to the naked eye"
  },
  {
    name: "UV Reactive Elements",
    description: "Features that only appear under ultraviolet light"
  },
  {
    name: "Tactile Features",
    description: "Raised elements that can be felt by touch"
  },
  {
    name: "Optical Variable Devices",
    description: "Elements that change color when viewed from different angles"
  }
];

export const FRAUD_PREVENTION_RESOURCES = [
  {
    title: "Understanding Identity Theft",
    url: "/learn/identity-theft"
  },
  {
    title: "Protecting Your Digital Identity",
    url: "/learn/digital-identity"
  },
  {
    title: "Recognizing Document Tampering",
    url: "/learn/document-tampering"
  },
  {
    title: "Security Feature Verification",
    url: "/learn/security-features"
  }
];
