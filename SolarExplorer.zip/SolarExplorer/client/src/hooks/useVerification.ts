import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { VerificationResult } from "@shared/schema";

const useVerification = () => {
  const [file, setFile] = useState<File | null>(null);
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();
  
  const { mutate, isPending: isVerifying } = useMutation({
    mutationFn: async (file: File) => {
      // Create form data for the file upload
      const formData = new FormData();
      formData.append('idImage', file);
      formData.append('documentType', 'id-card'); // Default document type
      
      // Simulate progress during verification
      const progressInterval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 95) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + Math.floor(Math.random() * 10) + 1;
        });
      }, 300);
      
      // Make the API request
      try {
        const response = await fetch('/api/verify', {
          method: 'POST',
          body: formData,
          credentials: 'include',
        });
        
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(errorText || response.statusText);
        }
        
        clearInterval(progressInterval);
        setProgress(100);
        
        const result = await response.json();
        return result;
      } catch (error) {
        clearInterval(progressInterval);
        throw error;
      }
    },
    onSuccess: (data) => {
      toast({
        title: "Verification Complete",
        description: "Your ID has been successfully analyzed.",
      });
      // Update the cache with the verification result
      queryClient.invalidateQueries({ queryKey: ['/api/verification-results'] });
    },
    onError: (error) => {
      setProgress(0);
      toast({
        title: "Verification Failed",
        description: error instanceof Error ? error.message : "Unknown error occurred",
        variant: "destructive",
      });
    }
  });
  
  const handleVerify = () => {
    if (!file) {
      toast({
        title: "No file selected",
        description: "Please upload an ID image first.",
        variant: "destructive",
      });
      return;
    }
    
    setProgress(0);
    mutate(file);
  };
  
  return {
    file,
    setFile,
    isUploading: false, // We don't have a separate upload step in this implementation
    isVerifying,
    progress,
    verificationResult: isVerifying ? null : (queryClient.getQueryData(['/api/verification-results']) as VerificationResult),
    handleVerify,
  };
};

export default useVerification;
