import { useEffect } from "react";
import Hero from "@/components/Hero";
import VerificationInterface from "@/components/VerificationInterface";
import EducationalSection from "@/components/EducationalSection";
import InteractiveGuide from "@/components/InteractiveGuide";
import CTA from "@/components/CTA";
import { useQuery } from "@tanstack/react-query";

const Home = () => {
  const { data: educationalResources, isLoading } = useQuery({
    queryKey: ['/api/resources'],
  });

  return (
    <div className="container mx-auto px-4 py-6">
      <Hero />
      <VerificationInterface />
      <EducationalSection resources={educationalResources || []} isLoading={isLoading} />
      <InteractiveGuide />
      <CTA />
    </div>
  );
};

export default Home;
