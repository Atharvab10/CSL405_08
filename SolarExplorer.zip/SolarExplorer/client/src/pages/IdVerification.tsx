import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Shield, Check, X, AlertCircle, Upload, Scan } from "lucide-react";
import FileUpload from "@/components/FileUpload";
import ScanAnimation from "@/components/ScanAnimation";
import useVerification from "@/hooks/useVerification";

const IdVerification = () => {
  const [activeTab, setActiveTab] = useState("upload");
  const { toast } = useToast();
  const { 
    file, 
    setFile, 
    isUploading, 
    isVerifying, 
    progress, 
    verificationResult, 
    handleVerify 
  } = useVerification();

  const moveToNextStep = () => {
    if (activeTab === "upload" && file) {
      setActiveTab("verify");
    } else if (activeTab === "verify" && !isVerifying) {
      setActiveTab("results");
    } else if (!file && activeTab === "upload") {
      toast({
        title: "No file selected",
        description: "Please select an ID image to continue.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl md:text-4xl font-orbitron font-bold mb-6 text-center">
          <span className="text-[#0066FF]">ID Verification</span> Simulator
        </h1>
        
        <p className="text-center mb-8 opacity-80 max-w-2xl mx-auto">
          Experience a simulation of how modern ID verification systems work. Upload an ID image and see the analysis process in action.
        </p>
        
        <Card className="bg-[#1E1E1E] border border-[#0066FF]/30 relative overflow-hidden">
          <div className="absolute inset-0 grid-pattern opacity-10"></div>
          
          <CardHeader className="relative z-10">
            <CardTitle className="font-orbitron text-[#00FF8D]">
              Interactive Verification Process
            </CardTitle>
            <CardDescription>
              Follow the steps below to learn about ID verification technology
            </CardDescription>
          </CardHeader>
          
          <CardContent className="relative z-10">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid grid-cols-3 mb-8">
                <TabsTrigger value="upload" className="font-orbitron text-sm">Step 1: Upload</TabsTrigger>
                <TabsTrigger value="verify" className="font-orbitron text-sm">Step 2: Verify</TabsTrigger>
                <TabsTrigger value="results" className="font-orbitron text-sm">Step 3: Results</TabsTrigger>
              </TabsList>
              
              <TabsContent value="upload" className="mt-0">
                <Card className="bg-[#121212] border border-[#0066FF]/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-orbitron text-[#0066FF]">ID Upload</CardTitle>
                    <CardDescription>Upload your identification document for verification</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <FileUpload file={file} setFile={setFile} isUploading={isUploading} />
                    
                    <div className="flex justify-between items-center mt-4">
                      <div className="flex items-center">
                        <Shield className="w-4 h-4 text-[#00FF8D] mr-1.5" />
                        <span className="text-xs">Secure encrypted upload</span>
                      </div>
                      <Button variant="link" size="sm" className="text-xs text-[#FF00AA]">
                        Need help?
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                
                <div className="flex justify-end mt-6">
                  <Button
                    onClick={moveToNextStep}
                    disabled={!file || isUploading}
                    className="bg-[#0066FF] hover:bg-[#0066FF]/80 text-white font-orbitron"
                  >
                    {isUploading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      'Continue to Verification'
                    )}
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="verify" className="mt-0">
                <Card className="bg-[#121212] border border-[#0066FF]/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-orbitron text-[#0066FF]">Verification Process</CardTitle>
                    <CardDescription>The system is analyzing your ID document</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="border border-[#0066FF]/30 rounded-lg p-4 relative">
                      <ScanAnimation isScanning={isVerifying} />
                      
                      <div className="mt-4 flex justify-between text-xs items-center">
                        <span>Verifying authenticity</span>
                        <span className="text-[#00FF8D]">{progress}% complete</span>
                      </div>
                      
                      <Progress value={progress} className="w-full h-1 bg-[#1E1E1E]/50 mt-1">
                        <div 
                          className="bg-[#00FF8D] h-full rounded-full transition-all duration-500 ease-in-out" 
                          style={{ width: `${progress}%` }}
                        ></div>
                      </Progress>
                    </div>
                  </CardContent>
                </Card>
                
                <div className="flex justify-end mt-6">
                  <Button
                    onClick={() => {
                      if (!isVerifying) {
                        handleVerify();
                      }
                    }}
                    disabled={isVerifying}
                    className="bg-[#0066FF] hover:bg-[#0066FF]/80 text-white font-orbitron"
                  >
                    {isVerifying ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      'Start Verification'
                    )}
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="results" className="mt-0">
                <Card className="bg-[#121212] border border-[#0066FF]/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-orbitron text-[#0066FF]">Verification Results</CardTitle>
                    <CardDescription>Analysis of your ID document</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {verificationResult ? (
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <h4 className="font-orbitron text-sm">Verification Score</h4>
                          <span className="text-[#00FF8D] font-orbitron text-lg">{verificationResult.overallScore}%</span>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between bg-[#1E1E1E]/50 p-2 rounded text-xs">
                            <span>Document authenticity</span>
                            <span className="text-[#00FF8D]">{verificationResult.authenticity}%</span>
                          </div>
                          <div className="flex justify-between bg-[#1E1E1E]/50 p-2 rounded text-xs">
                            <span>Security features</span>
                            <span className="text-[#00FF8D]">{verificationResult.securityFeatures}%</span>
                          </div>
                          <div className="flex justify-between bg-[#1E1E1E]/50 p-2 rounded text-xs">
                            <span>Expiration date</span>
                            <span className={verificationResult.expirationStatus ? "text-[#00FF8D]" : "text-[#FF00AA]"}>
                              {verificationResult.expirationStatus ? "Valid" : "Expired"}
                            </span>
                          </div>
                          <div className="flex justify-between bg-[#1E1E1E]/50 p-2 rounded text-xs">
                            <span>Tampering detection</span>
                            <span className={verificationResult.tamperingDetected ? "text-[#FF00AA]" : "text-[#00FF8D]"}>
                              {verificationResult.tamperingDetected ? "Tampering detected" : "No tampering detected"}
                            </span>
                          </div>
                        </div>
                        
                        <Button className="w-full bg-[#1E1E1E] text-[#00FF8D] border border-[#00FF8D] hover:bg-[#00FF8D]/10 font-orbitron text-sm">
                          Generate Report
                        </Button>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-48">
                        <AlertCircle className="h-12 w-12 text-[#FF00AA] mb-2" />
                        <p className="text-center opacity-70">No verification results available yet. Complete the verification process to see results.</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
                
                <div className="flex justify-end mt-6 space-x-3">
                  <Button 
                    variant="outline"
                    onClick={() => {
                      setFile(null);
                      setActiveTab("upload");
                    }}
                    className="border-[#00FF8D] text-[#00FF8D] hover:bg-[#00FF8D]/10"
                  >
                    Start New Verification
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default IdVerification;
