import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle, Shield, Info, BookOpen } from "lucide-react";
import { motion } from "framer-motion";
import type { EducationalResource } from "@shared/schema";

const Learn = () => {
  const { data: resources, isLoading } = useQuery({
    queryKey: ['/api/resources'],
  });

  const categoryMap: Record<string, { title: string, icon: JSX.Element }> = {
    'fraud-prevention': { 
      title: 'Fraud Prevention', 
      icon: <AlertCircle className="w-5 h-5 text-[#FF00AA]" /> 
    },
    'security-features': { 
      title: 'Security Features', 
      icon: <Shield className="w-5 h-5 text-[#0066FF]" /> 
    },
    'biometrics': { 
      title: 'Biometric Technologies', 
      icon: <Info className="w-5 h-5 text-[#00FF8D]" /> 
    },
  };

  // Group resources by category
  const resourcesByCategory = resources?.reduce((acc: Record<string, EducationalResource[]>, resource) => {
    if (!acc[resource.category]) {
      acc[resource.category] = [];
    }
    acc[resource.category].push(resource);
    return acc;
  }, {}) || {};

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-orbitron font-bold mb-4">
          <span className="text-[#0066FF]">Learn About</span> ID Fraud Protection
        </h1>
        <p className="max-w-2xl mx-auto opacity-80">
          Explore our educational resources to understand the technologies and methods used in identity verification and fraud prevention.
        </p>
      </div>

      <div className="max-w-5xl mx-auto">
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="w-full justify-start overflow-x-auto mb-8">
            <TabsTrigger value="all" className="font-orbitron">All Resources</TabsTrigger>
            {Object.entries(categoryMap).map(([key, { title }]) => (
              <TabsTrigger key={key} value={key} className="font-orbitron">{title}</TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="all">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {isLoading ? (
                Array(6).fill(0).map((_, i) => (
                  <ResourceSkeleton key={i} />
                ))
              ) : (
                resources?.map((resource) => (
                  <ResourceCard 
                    key={resource.id} 
                    resource={resource} 
                    categoryInfo={categoryMap[resource.category]}
                  />
                ))
              )}
            </div>
          </TabsContent>

          {Object.keys(categoryMap).map((category) => (
            <TabsContent key={category} value={category}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {isLoading ? (
                  Array(3).fill(0).map((_, i) => (
                    <ResourceSkeleton key={i} />
                  ))
                ) : (
                  resourcesByCategory[category]?.map((resource) => (
                    <ResourceCard 
                      key={resource.id} 
                      resource={resource} 
                      categoryInfo={categoryMap[resource.category]}
                    />
                  ))
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>

      <div className="mt-16 bg-[#1E1E1E] border border-[#0066FF]/30 rounded-xl p-8 grid-pattern relative overflow-hidden">
        <div className="absolute inset-0 grid-pattern opacity-10"></div>
        <div className="relative z-10">
          <div className="flex items-start mb-6">
            <BookOpen className="w-10 h-10 text-[#00FF8D] mr-4" />
            <div>
              <h2 className="text-2xl font-orbitron text-[#00FF8D]">Advanced Cybersecurity Topics</h2>
              <p className="opacity-80 mt-2">
                Dive deeper into advanced topics in cybersecurity and identity protection.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            <Card className="bg-[#121212] border border-[#0066FF]/30 hover:border-[#0066FF] transition-colors">
              <CardHeader>
                <CardTitle className="font-orbitron text-[#0066FF]">Machine Learning in Fraud Detection</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="opacity-80 mb-4">
                  Learn how AI and machine learning algorithms are revolutionizing the way we detect and prevent identity fraud.
                </p>
                <p className="text-[#00FF8D] text-sm hover:underline cursor-pointer">Coming soon →</p>
              </CardContent>
            </Card>

            <Card className="bg-[#121212] border border-[#0066FF]/30 hover:border-[#0066FF] transition-colors">
              <CardHeader>
                <CardTitle className="font-orbitron text-[#0066FF]">Blockchain Identity Solutions</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="opacity-80 mb-4">
                  Explore how blockchain technology is creating new possibilities for secure, decentralized identity verification.
                </p>
                <p className="text-[#00FF8D] text-sm hover:underline cursor-pointer">Coming soon →</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

const ResourceCard = ({ resource, categoryInfo }: { 
  resource: EducationalResource; 
  categoryInfo: { title: string; icon: JSX.Element; }; 
}) => {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="bg-[#1E1E1E] border border-[#0066FF]/30 hover:border-[#0066FF] transition-colors h-full overflow-hidden">
        <div className="h-48 relative overflow-hidden">
          <div 
            className="w-full h-full bg-cover bg-center transform transition-transform duration-500 hover:scale-110"
            style={{ backgroundImage: `url(${resource.imageUrl})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#121212] to-transparent"></div>
          <div className="absolute bottom-4 left-4">
            <h3 className="font-orbitron text-[#00FF8D] text-lg">{resource.title}</h3>
          </div>
        </div>
        
        <CardContent className="p-5 space-y-3">
          <p className="text-sm opacity-90">{resource.description}</p>
          
          <div className="flex items-center space-x-2">
            <div className="rounded-full bg-[#0066FF]/20 p-1.5">
              {categoryInfo.icon}
            </div>
            <span className="text-xs">{categoryInfo.title}</span>
          </div>
          
          <div className="space-y-2">
            {resource.content.split(',').map((item, i) => (
              <div key={i} className="flex items-center">
                <div className="rounded-full bg-[#0066FF]/20 p-1.5 mr-2">
                  <Info className="w-3 h-3 text-[#0066FF]" />
                </div>
                <span className="text-xs">{item.trim()}</span>
              </div>
            ))}
          </div>
          
          <a href="#" className="block mt-4 text-[#0066FF] text-sm hover:underline">Read more →</a>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const ResourceSkeleton = () => {
  return (
    <Card className="bg-[#1E1E1E] border border-[#0066FF]/30">
      <Skeleton className="h-48 w-full bg-[#121212]/60" />
      <CardContent className="p-5">
        <Skeleton className="h-5 w-3/4 bg-[#121212]/60 mb-4" />
        <Skeleton className="h-12 w-full bg-[#121212]/60 mb-4" />
        <div className="space-y-2">
          <Skeleton className="h-4 w-full bg-[#121212]/60" />
          <Skeleton className="h-4 w-3/4 bg-[#121212]/60" />
          <Skeleton className="h-4 w-2/3 bg-[#121212]/60" />
        </div>
      </CardContent>
    </Card>
  );
};

export default Learn;
