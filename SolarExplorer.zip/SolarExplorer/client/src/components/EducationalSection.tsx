import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Info } from "lucide-react";
import { motion } from "framer-motion";
import type { EducationalResource } from "@shared/schema";

interface EducationalSectionProps {
  resources: EducationalResource[];
  isLoading: boolean;
}

const EducationalSection = ({ resources, isLoading }: EducationalSectionProps) => {
  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
      className="my-16"
    >
      <h2 className="font-orbitron text-2xl mb-8 text-center">
        <span className="text-[#0066FF]">Understanding</span> ID Fraud Protection
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array(3).fill(0).map((_, index) => (
            <EducationalCardSkeleton key={index} />
          ))
        ) : (
          resources.map((resource) => (
            <EducationalCard key={resource.id} resource={resource} />
          ))
        )}
      </div>

      <div className="mt-8 text-center">
        <Link href="/learn">
          <a className="inline-block text-[#0066FF] text-lg font-orbitron hover:text-[#00FF8D] transition-colors">
            View All Resources →
          </a>
        </Link>
      </div>
    </motion.section>
  );
};

const EducationalCard = ({ resource }: { resource: EducationalResource }) => {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="bg-[#1E1E1E] rounded-lg overflow-hidden shadow-lg border border-[#0066FF]/30 hover:border-[#0066FF] transition-colors group h-full">
        <div className="h-48 relative overflow-hidden">
          <div 
            className="w-full h-full bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
            style={{ backgroundImage: `url(${resource.imageUrl})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#121212] to-transparent"></div>
          <div className="absolute bottom-4 left-4">
            <h3 className="font-orbitron text-[#00FF8D] text-lg">{resource.title}</h3>
          </div>
        </div>
        
        <CardContent className="p-5 space-y-3">
          <p className="text-sm opacity-90">{resource.description}</p>
          
          <div className="space-y-2">
            {resource.content.split(',').map((item, index) => (
              <div key={index} className="flex items-center">
                <div className="rounded-full bg-[#0066FF]/20 p-1.5 mr-2">
                  <Info className="w-3 h-3 text-[#0066FF]" />
                </div>
                <span className="text-xs">{item.trim()}</span>
              </div>
            ))}
          </div>
          
          <Link href={`/learn#${resource.id}`}>
            <a className="block mt-4 text-[#0066FF] text-sm hover:underline">Read more →</a>
          </Link>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const EducationalCardSkeleton = () => {
  return (
    <Card className="bg-[#1E1E1E] rounded-lg overflow-hidden shadow-lg border border-[#0066FF]/30">
      <Skeleton className="h-48 w-full bg-[#121212]/60" />
      <CardContent className="p-5 space-y-3">
        <Skeleton className="h-12 w-full bg-[#121212]/60" />
        
        <div className="space-y-2">
          <Skeleton className="h-6 w-full bg-[#121212]/60" />
          <Skeleton className="h-6 w-full bg-[#121212]/60" />
          <Skeleton className="h-6 w-3/4 bg-[#121212]/60" />
        </div>
      </CardContent>
    </Card>
  );
};

export default EducationalSection;
