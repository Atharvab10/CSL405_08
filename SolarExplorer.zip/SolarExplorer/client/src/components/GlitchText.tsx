import { useEffect, useState } from 'react';

interface GlitchTextProps {
  text: string;
  className?: string;
  glitchInterval?: number;
  glitchDuration?: number;
}

const GlitchText = ({ 
  text, 
  className = "", 
  glitchInterval = 3000, 
  glitchDuration = 200 
}: GlitchTextProps) => {
  const [isGlitching, setIsGlitching] = useState(false);
  
  useEffect(() => {
    // Start the glitch effect at a random time to avoid all glitch texts
    // glitching at the same time
    const initialDelay = Math.random() * 1000;
    
    const timeout = setTimeout(() => {
      const interval = setInterval(() => {
        setIsGlitching(true);
        setTimeout(() => {
          setIsGlitching(false);
        }, glitchDuration);
      }, glitchInterval);
      
      return () => clearInterval(interval);
    }, initialDelay);
    
    return () => clearTimeout(timeout);
  }, [glitchInterval, glitchDuration]);
  
  // Create glitched text with random characters
  const generateGlitchedText = () => {
    // Characters to use for glitching
    const glitchChars = "!<>-_\\/[]{}—=+*^?#________";
    
    // Create a copy of the original text
    let glitchedText = text.split('');
    
    // Replace random characters (30% chance for each character)
    glitchedText = glitchedText.map(char => {
      if (Math.random() < 0.3) {
        return glitchChars[Math.floor(Math.random() * glitchChars.length)];
      }
      return char;
    });
    
    return glitchedText.join('');
  };
  
  return (
    <span 
      className={`relative inline-block ${className} ${isGlitching ? 'text-[#FF00AA]' : ''}`}
      data-text={text}
    >
      {isGlitching ? generateGlitchedText() : text}
      
      {isGlitching && (
        <>
          <span 
            className="absolute top-0 left-0 w-full"
            style={{ 
              clipPath: 'rect(8px, 999px, 15px, 0)',
              transform: 'translate(-3px, 0)',
              opacity: 0.7,
              color: '#0066FF'
            }}
          >
            {text}
          </span>
          <span 
            className="absolute top-0 left-0 w-full"
            style={{ 
              clipPath: 'rect(5px, 999px, 25px, 0)',
              transform: 'translate(3px, 0)',
              opacity: 0.7,
              color: '#00FF8D'
            }}
          >
            {text}
          </span>
        </>
      )}
    </span>
  );
};

export default GlitchText;