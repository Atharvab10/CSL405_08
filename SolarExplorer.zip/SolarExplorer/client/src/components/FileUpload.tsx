import { useState, useRef } from "react";
import { Upload, X } from "lucide-react";
import { motion } from "framer-motion";

interface FileUploadProps {
  file: File | null;
  setFile: (file: File | null) => void;
  isUploading: boolean;
}

const FileUpload = ({ file, setFile, isUploading }: FileUploadProps) => {
  const [dragActive, setDragActive] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const uploadedFile = e.dataTransfer.files[0];
      validateAndSetFile(uploadedFile);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    
    if (e.target.files && e.target.files[0]) {
      const uploadedFile = e.target.files[0];
      validateAndSetFile(uploadedFile);
    }
  };

  const validateAndSetFile = (uploadedFile: File) => {
    // Check file type
    const validTypes = ['image/jpeg', 'image/png'];
    if (!validTypes.includes(uploadedFile.type)) {
      alert('Please upload a JPG or PNG file');
      return;
    }
    
    // Check file size (5MB max)
    if (uploadedFile.size > 5 * 1024 * 1024) {
      alert('File size exceeds 5MB limit');
      return;
    }
    
    setFile(uploadedFile);
  };

  const handleButtonClick = () => {
    inputRef.current?.click();
  };

  const handleRemoveFile = () => {
    setFile(null);
    if (inputRef.current) {
      inputRef.current.value = '';
    }
  };

  return (
    <div 
      className={`border-2 border-dashed ${
        dragActive ? 'border-[#00FF8D]' : 'border-[#0066FF]/50'
      } rounded-lg p-6 flex flex-col items-center justify-center h-48 relative transition-all hover:border-[#0066FF] cursor-pointer`}
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
      onClick={handleButtonClick}
    >
      {file ? (
        <div className="w-full h-full flex flex-col items-center justify-center relative">
          <div 
            className="absolute top-0 right-0 p-1"
            onClick={(e) => {
              e.stopPropagation();
              handleRemoveFile();
            }}
          >
            <X className="h-5 w-5 text-[#FF00AA] hover:text-white transition-colors" />
          </div>
          
          <div className="flex flex-col items-center">
            <div className="w-12 h-12 rounded-lg overflow-hidden mb-2">
              <img 
                src={URL.createObjectURL(file)} 
                alt="Preview" 
                className="w-full h-full object-cover"
              />
            </div>
            <p className="text-sm font-medium truncate max-w-[90%]">{file.name}</p>
            <p className="text-xs opacity-60 mt-1">
              {(file.size / 1024 / 1024).toFixed(2)} MB
            </p>
          </div>
        </div>
      ) : (
        <>
          <motion.div 
            animate={{ y: [0, -5, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Upload className="w-10 h-10 text-[#0066FF] mb-2" />
          </motion.div>
          <p className="text-sm text-center">Drag & drop your ID or click to upload</p>
          <p className="text-xs opacity-60 mt-2">Supports JPG, PNG (max 5MB)</p>
        </>
      )}
      
      <input
        ref={inputRef}
        type="file"
        className="absolute inset-0 opacity-0 cursor-pointer"
        onChange={handleChange}
        accept="image/png, image/jpeg"
        disabled={isUploading}
      />
    </div>
  );
};

export default FileUpload;
