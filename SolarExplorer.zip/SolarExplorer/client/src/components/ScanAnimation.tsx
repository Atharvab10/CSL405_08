import { useEffect, useRef } from "react";
import { motion, useAnimation } from "framer-motion";

interface ScanAnimationProps {
  isScanning: boolean;
}

const ScanAnimation = ({ isScanning }: ScanAnimationProps) => {
  const scanLineRef = useRef<HTMLDivElement>(null);
  const controls = useAnimation();

  useEffect(() => {
    if (isScanning) {
      controls.start({
        y: ["0%", "100%", "0%"],
        transition: {
          duration: 3,
          ease: "linear",
          repeat: Infinity,
        }
      });
    } else {
      controls.stop();
    }
  }, [isScanning, controls]);

  return (
    <div className="relative w-full h-32 bg-[#1E1E1E]/50 rounded flex items-center justify-center overflow-hidden">
      {isScanning && (
        <motion.div 
          ref={scanLineRef}
          animate={controls}
          className="absolute left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#00FF8D] to-transparent"
        />
      )}
      
      <div className="text-center">
        <div className="inline-block rounded-full bg-[#0066FF]/20 p-3 mb-2">
          <svg className="w-6 h-6 text-[#0066FF] animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"></path>
          </svg>
        </div>
        <p className="text-sm">{isScanning ? "Scanning document..." : "Ready to scan"}</p>
      </div>
    </div>
  );
};

export default ScanAnimation;
