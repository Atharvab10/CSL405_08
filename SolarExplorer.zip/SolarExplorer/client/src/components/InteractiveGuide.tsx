import { Button } from "@/components/ui/button";
import { Shield, Settings, Zap } from "lucide-react";
import { motion } from "framer-motion";
import ThreeJsCharacter from "@/components/ThreeJsCharacter";

const InteractiveGuide = () => {
  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.7 }}
      className="my-16 relative"
    >
      <div className="absolute inset-0 grid-pattern opacity-10"></div>
      
      <div className="bg-[#1E1E1E] rounded-xl overflow-hidden border border-[#0066FF]/30 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2">
          <div className="p-8 md:p-10">
            <h2 className="font-orbitron text-2xl mb-4 text-[#00FF8D]">Interactive Security Guide</h2>
            <p className="opacity-90 mb-6">Our virtual assistant will walk you through the most common identity theft scenarios and teach you how to protect yourself.</p>
            
            <div className="space-y-4">
              <motion.div 
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.9 }}
                className="flex"
              >
                <div className="mr-4 flex-shrink-0 rounded-full bg-[#0066FF]/20 p-2 self-start mt-1">
                  <Shield className="w-4 h-4 text-[#0066FF]" />
                </div>
                <div>
                  <h3 className="font-orbitron text-[#0066FF] text-sm mb-1">Personalized Security Assessment</h3>
                  <p className="text-sm opacity-80">Get tailored recommendations based on your online habits and digital footprint.</p>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 1.0 }}
                className="flex"
              >
                <div className="mr-4 flex-shrink-0 rounded-full bg-[#0066FF]/20 p-2 self-start mt-1">
                  <Settings className="w-4 h-4 text-[#0066FF]" />
                </div>
                <div>
                  <h3 className="font-orbitron text-[#0066FF] text-sm mb-1">Interactive Simulations</h3>
                  <p className="text-sm opacity-80">Practice identifying phishing attempts and social engineering tactics in a safe environment.</p>
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 1.1 }}
                className="flex"
              >
                <div className="mr-4 flex-shrink-0 rounded-full bg-[#0066FF]/20 p-2 self-start mt-1">
                  <Zap className="w-4 h-4 text-[#0066FF]" />
                </div>
                <div>
                  <h3 className="font-orbitron text-[#0066FF] text-sm mb-1">Real-Time Learning</h3>
                  <p className="text-sm opacity-80">Our AI assistant adapts to your knowledge level and progress through the materials.</p>
                </div>
              </motion.div>
            </div>
            
            <motion.div 
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 1.2 }}
            >
              <Button className="mt-8 px-6 py-3 bg-[#00FF8D] text-[#121212] rounded-md font-orbitron font-medium transition-all hover:bg-opacity-80">
                Launch Interactive Guide
              </Button>
            </motion.div>
          </div>
          
          <div className="relative h-96 md:h-auto overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-[#1E1E1E] to-transparent z-10 md:block hidden"></div>
            
            <div className="h-full w-full bg-[#121212] relative">
              <ThreeJsCharacter />
              
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <motion.div 
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ delay: 1.3, type: "spring" }}
                    className="inline-block rounded-full bg-[#00FF8D]/20 p-4 mb-4 animate-pulse-slow"
                  >
                    <svg className="w-10 h-10 text-[#00FF8D]" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path>
                    </svg>
                  </motion.div>
                  <p className="font-orbitron text-[#00FF8D] text-lg glow-text">AI ASSISTANT</p>
                  <p className="text-sm opacity-80 max-w-xs mx-auto mt-2">3D character interactive guide</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.section>
  );
};

export default InteractiveGuide;
