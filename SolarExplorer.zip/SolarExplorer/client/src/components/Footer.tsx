import { Link } from "wouter";
import { Shield, Twitter, Instagram, Facebook, Linkedin } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const Footer = () => {
  return (
    <footer className="relative z-10 bg-[#1E1E1E] border-t border-[#0066FF]/30 py-10 px-4">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <Link href="/">
              <a className="flex items-center mb-4">
                <div className="w-8 h-8 mr-2 rounded-full bg-gradient-to-br from-[#0066FF] to-[#00FF8D] flex items-center justify-center">
                  <Shield className="w-4 h-4 text-[#121212]" />
                </div>
                <h2 className="font-orbitron text-lg font-bold tracking-wider">
                  <span className="text-[#0066FF]">Cyber</span>
                  <span className="text-[#00FF8D]">Shield</span>
                </h2>
              </a>
            </Link>
            <p className="text-sm opacity-70 mb-4">
              Educating and protecting users against identity theft through interactive learning and verification tools.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-[#0066FF] hover:text-[#00FF8D] transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-[#0066FF] hover:text-[#00FF8D] transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="text-[#0066FF] hover:text-[#00FF8D] transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="text-[#0066FF] hover:text-[#00FF8D] transition-colors">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-orbitron text-[#0066FF] mb-4 text-sm">Resources</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-[#00FF8D] transition-colors">ID Verification Guide</a></li>
              <li><a href="#" className="hover:text-[#00FF8D] transition-colors">Fraud Prevention</a></li>
              <li><a href="#" className="hover:text-[#00FF8D] transition-colors">Security Best Practices</a></li>
              <li><a href="#" className="hover:text-[#00FF8D] transition-colors">Identity Theft Recovery</a></li>
              <li><a href="#" className="hover:text-[#00FF8D] transition-colors">Document Library</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-orbitron text-[#0066FF] mb-4 text-sm">Company</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-[#00FF8D] transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-[#00FF8D] transition-colors">Our Team</a></li>
              <li><a href="#" className="hover:text-[#00FF8D] transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-[#00FF8D] transition-colors">Press Kit</a></li>
              <li><a href="#" className="hover:text-[#00FF8D] transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-orbitron text-[#0066FF] mb-4 text-sm">Stay Updated</h3>
            <p className="text-sm opacity-70 mb-4">Subscribe to our newsletter for the latest security tips and updates.</p>
            <form className="space-y-2">
              <div className="relative">
                <Input 
                  type="email" 
                  placeholder="Your email address" 
                  className="w-full bg-[#121212] border border-[#0066FF]/30 rounded-md py-2 px-3 focus:outline-none focus:border-[#0066FF] text-sm"
                />
              </div>
              <Button type="submit" className="w-full bg-[#0066FF] py-2 rounded-md text-[#121212] font-orbitron text-sm transition-colors hover:bg-opacity-80">
                Subscribe
              </Button>
            </form>
          </div>
        </div>
        
        <div className="mt-10 pt-6 border-t border-[#0066FF]/20 flex flex-col md:flex-row justify-between items-center text-xs opacity-70">
          <p>© 2023 CyberShield. All rights reserved.</p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <a href="#" className="hover:text-[#00FF8D] transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-[#00FF8D] transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-[#00FF8D] transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
