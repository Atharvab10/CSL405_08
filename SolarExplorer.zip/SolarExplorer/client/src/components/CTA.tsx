import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

const CTA = () => {
  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.9 }}
      className="my-16 text-center"
    >
      <h2 className="font-orbitron text-2xl mb-4">
        Ready to <span className="text-[#0066FF]">secure</span> your identity?
      </h2>
      <p className="max-w-xl mx-auto opacity-90 mb-8">
        Take the first step in protecting yourself from identity theft. Sign up for personalized security alerts and advanced protection features.
      </p>
      
      <div className="flex flex-col md:flex-row justify-center space-y-4 md:space-y-0 md:space-x-6">
        <Button className="px-8 py-3 bg-[#0066FF] rounded-md font-orbitron font-medium transition-all hover:bg-opacity-80 glow-border">
          Create Free Account
        </Button>
        <Button variant="outline" className="px-8 py-3 bg-transparent border border-[#00FF8D] text-[#00FF8D] rounded-md font-orbitron font-medium transition-all hover:bg-[#00FF8D] hover:bg-opacity-10">
          Browse Resources
        </Button>
      </div>
    </motion.section>
  );
};

export default CTA;
