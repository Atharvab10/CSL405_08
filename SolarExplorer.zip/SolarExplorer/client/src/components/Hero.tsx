import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion, useMotionValue, useTransform, useInView } from "framer-motion";
import ThreeJsCharacter from "@/components/ThreeJsCharacter";
import GlitchText from "@/components/GlitchText";
import { Eye, Shield, Fingerprint, Lock, PieChart } from "lucide-react";
import { useRef, useState, useEffect } from "react";

const Hero = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: false, margin: "-100px" });
  
  // Mouse follower effect
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  
  useEffect(() => {
    const updateMousePosition = (e: MouseEvent) => {
      if (!sectionRef.current) return;
      
      // Get section bounds
      const rect = sectionRef.current.getBoundingClientRect();
      
      // Calculate mouse position relative to section
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      setMousePosition({ x, y });
    };
    
    // Only track mouse position when section is in view
    if (isInView) {
      window.addEventListener("mousemove", updateMousePosition);
    }
    
    return () => {
      window.removeEventListener("mousemove", updateMousePosition);
    };
  }, [isInView]);
  
  // Update motion values with spring physics
  useEffect(() => {
    const springConfig = { damping: 30, stiffness: 300 };
    
    // Animate mouseX and mouseY with spring physics for smooth following
    const springX = () => {
      const dx = mousePosition.x - mouseX.get();
      mouseX.set(mouseX.get() + dx * 0.1);
      requestAnimationFrame(springX);
    };
    
    const springY = () => {
      const dy = mousePosition.y - mouseY.get();
      mouseY.set(mouseY.get() + dy * 0.1);
      requestAnimationFrame(springY);
    };
    
    springX();
    springY();
  }, [mousePosition]);
  
  // Transform values for parallax effect
  const rotateX = useTransform(mouseY, [0, 500], [5, -5]);
  const rotateY = useTransform(mouseX, [0, 500], [-5, 5]);
  
  // For floating security features
  const [securityFeatures] = useState([
    { 
      icon: <Eye className="w-5 h-5 text-[#0066FF]" />, 
      text: "Biometric Verification", 
      delay: 0.1 
    },
    { 
      icon: <Fingerprint className="w-5 h-5 text-[#00FF8D]" />, 
      text: "Multi-Factor Authentication", 
      delay: 0.2 
    },
    { 
      icon: <Shield className="w-5 h-5 text-[#FF00AA]" />, 
      text: "Real-Time Fraud Detection", 
      delay: 0.3 
    },
    { 
      icon: <Lock className="w-5 h-5 text-[#0066FF]" />, 
      text: "Encrypted Documents", 
      delay: 0.4 
    },
    { 
      icon: <PieChart className="w-5 h-5 text-[#00FF8D]" />, 
      text: "AI-Powered Analysis", 
      delay: 0.5 
    },
  ]);
  
  // Glitch text animation for security counters
  const [counters] = useState([
    { label: "THREATS DETECTED", value: "1,337", color: "#FF00AA" },
    { label: "IDs VERIFIED", value: "8,942", color: "#0066FF" },
    { label: "SECURITY SCORE", value: "99.8%", color: "#00FF8D" },
  ]);

  return (
    <motion.section 
      ref={sectionRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="container mx-auto py-16 relative overflow-hidden"
    >
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full hex-pattern opacity-20 z-0"></div>
      
      {/* Grid pattern overlay */}
      <div className="absolute inset-0 grid-pattern opacity-20 z-0"></div>
      
      {/* Mouse follower gradient */}
      <motion.div 
        className="absolute rounded-full w-64 h-64 opacity-20 pointer-events-none z-0"
        style={{
          background: "radial-gradient(circle, rgba(0,255,141,0.3) 0%, rgba(0,102,255,0.2) 50%, rgba(0,0,0,0) 70%)",
          x: mouseX,
          y: mouseY,
          translateX: "-50%",
          translateY: "-50%"
        }}
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 relative z-10">
        <motion.div 
          initial={{ x: -80, opacity: 0 }}
          animate={isInView ? { x: 0, opacity: 1 } : { x: -80, opacity: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="space-y-8 px-4"
        >
          <div className="inline-block py-1 px-3 rounded-full bg-[#0066FF]/10 border border-[#0066FF]/30">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 rounded-full bg-[#0066FF] animate-pulse"></div>
              <span className="text-xs font-mono text-[#0066FF]">CYBERSECURITY MODULE</span>
            </div>
          </div>
          
          <div>
            <h1 className="font-orbitron text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4">
              <GlitchText text="ID Verification" className="text-[#0066FF]" glitchInterval={5000} />
              <br/>
              <span className="text-gradient">Education Portal</span>
            </h1>
            <p className="text-xl opacity-90 leading-relaxed">
              Learn how identity verification works and protect yourself from fraud with our interactive simulation and educational resources.
            </p>
          </div>
          
          <div className="flex flex-wrap gap-4 items-center">
            {counters.map((counter, index) => (
              <motion.div 
                key={index}
                initial={{ y: 20, opacity: 0 }}
                animate={isInView ? { y: 0, opacity: 1 } : { y: 20, opacity: 0 }}
                transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
                className="bg-glass p-3 rounded-lg min-w-[120px]"
              >
                <div className="text-xs font-mono opacity-70">{counter.label}</div>
                <div className="font-orbitron font-bold text-lg" style={{ color: counter.color }}>
                  {counter.value}
                </div>
              </motion.div>
            ))}
          </div>
          
          <motion.div 
            initial={{ y: 30, opacity: 0 }}
            animate={isInView ? { y: 0, opacity: 1 } : { y: 30, opacity: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <Link href="/verify">
              <a className="w-full sm:w-auto">
                <Button className="w-full sm:w-auto px-8 py-5 bg-[#0066FF] text-white rounded-md font-orbitron font-medium transition-all hover:bg-opacity-80 hover:translate-y-[-2px] hover:shadow-[0_0_15px_rgba(0,102,255,0.5)] group">
                  <span>Start Verification</span>
                  <motion.span
                    initial={{ x: 0 }}
                    animate={{ x: [0, 5, 0] }}
                    transition={{ duration: 1, repeat: Infinity, repeatDelay: 1 }}
                    className="ml-2"
                  >
                    →
                  </motion.span>
                </Button>
              </a>
            </Link>
            <Link href="/learn">
              <a className="w-full sm:w-auto">
                <Button variant="outline" className="w-full sm:w-auto px-8 py-5 bg-transparent border-2 border-[#00FF8D] text-[#00FF8D] rounded-md font-orbitron font-medium transition-all hover:bg-[#00FF8D]/10">
                  Learn More
                </Button>
              </a>
            </Link>
          </motion.div>
          
          {/* Floating security features */}
          <div className="relative h-16 mt-8">
            {securityFeatures.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ y: 20, opacity: 0 }}
                animate={isInView ? { y: 0, opacity: 1 } : { y: 20, opacity: 0 }}
                transition={{ delay: 0.7 + feature.delay, duration: 0.5 }}
                className="absolute flex items-center space-x-2 bg-glass rounded-full py-1 px-3"
                style={{
                  top: `${(index * 30) % 60}px`,
                  left: `${index * 20}%`,
                }}
              >
                {feature.icon}
                <span className="text-xs whitespace-nowrap">{feature.text}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>
        
        <motion.div 
          style={{ 
            perspective: 1000,
            rotateX,
            rotateY,
          }}
          initial={{ y: 80, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : { y: 80, opacity: 0 }}
          transition={{ delay: 0.3, duration: 0.8, ease: "easeOut" }}
          className="relative flex items-center justify-center"
        >
          <motion.div 
            className="relative w-full md:w-[90%] max-w-[500px] h-[400px] rounded-2xl border-2 border-[#0066FF]/30 bg-glass overflow-hidden"
            style={{ boxShadow: "0 10px 30px rgba(0, 102, 255, 0.2)" }}
          >
            {/* Scanline effect */}
            <div className="absolute inset-0 overflow-hidden">
              <div className="scanline"></div>
            </div>
            
            {/* Character container */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="relative w-full h-full">
                <ThreeJsCharacter />
              </div>
              
              {/* Holographic interface elements */}
              <div className="absolute top-4 left-4 right-4 flex justify-between">
                <div className="cyber-badge px-2 py-1 bg-[#0066FF]/20 border border-[#0066FF]/30 rounded-md">
                  <div className="text-xs font-mono text-[#0066FF]">SYSTEM ACTIVE</div>
                </div>
                
                <div className="flex space-x-2">
                  {[1, 2, 3].map((_, i) => (
                    <div 
                      key={i}
                      className="w-6 h-6 rounded-full flex items-center justify-center"
                      style={{ 
                        backgroundColor: `rgba(0, ${i === 0 ? 102 : 255}, ${i === 2 ? 141 : (i === 0 ? 255 : 0)}, 0.2)`,
                        border: `1px solid rgba(0, ${i === 0 ? 102 : 255}, ${i === 2 ? 141 : (i === 0 ? 255 : 0)}, 0.4)`
                      }}
                    >
                      <div 
                        className="w-2 h-2 rounded-full"
                        style={{ 
                          backgroundColor: `rgb(0, ${i === 0 ? 102 : 255}, ${i === 2 ? 141 : (i === 0 ? 255 : 0)})`,
                          animation: `pulse ${1 + i * 0.5}s cubic-bezier(0.4, 0, 0.6, 1) infinite`
                        }}
                      ></div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Bottom info panel */}
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-[#0d0d20]/60 border-t border-[#0066FF]/30 backdrop-blur-sm">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs font-mono opacity-60">ASSISTANT MODEL</div>
                    <div className="font-orbitron text-[#00FF8D] text-lg">CyberShield</div>
                  </div>
                  
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-md bg-gradient-to-br from-[#0066FF] to-[#00FF8D] flex items-center justify-center mr-2">
                      <Shield className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <div className="text-xs opacity-60">Security Level</div>
                      <div className="font-orbitron text-[#00FF8D]">Maximum</div>
                    </div>
                  </div>
                </div>
                
                {/* Loading bar */}
                <div className="mt-2 bg-[#1E1E1E] h-[6px] rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-gradient-to-r from-[#0066FF] to-[#00FF8D]"
                    initial={{ width: 0 }}
                    animate={{ width: ["0%", "100%", "30%", "100%", "60%", "100%"] }}
                    transition={{ duration: 10, repeat: Infinity, repeatType: "reverse" }}
                  ></motion.div>
                </div>
              </div>
            </div>
          </motion.div>
          
          {/* Decorative elements */}
          <div className="absolute -top-4 -left-4 w-12 h-12 border-t-2 border-l-2 border-[#0066FF] opacity-60"></div>
          <div className="absolute -bottom-4 -right-4 w-12 h-12 border-b-2 border-r-2 border-[#00FF8D] opacity-60"></div>
        </motion.div>
      </div>
      
      {/* Tech lines/circuit patterns */}
      <svg className="absolute bottom-0 left-0 w-full h-32 opacity-20 z-0" viewBox="0 0 1440 120" fill="none">
        <path d="M0 40H200V80H400V0H600V40H800V80H1000V40H1200V0H1440" stroke="#0066FF" strokeWidth="2" strokeDasharray="8 8" />
        <path d="M0 80H300V40H500V120H700V80H900V40H1100V80H1300V40H1440" stroke="#00FF8D" strokeWidth="2" strokeDasharray="5 5" />
      </svg>
    </motion.section>
  );
};

export default Hero;
