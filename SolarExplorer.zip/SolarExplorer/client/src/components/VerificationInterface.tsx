import { useState } from "react";
import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Loader2, Shield, Upload, Zap } from "lucide-react";
import { motion } from "framer-motion";
import FileUpload from "@/components/FileUpload";
import ScanAnimation from "@/components/ScanAnimation";
import useVerification from "@/hooks/useVerification";

const VerificationInterface = () => {
  const { 
    file, 
    setFile, 
    isUploading, 
    isVerifying, 
    progress, 
    verificationResult, 
    handleVerify 
  } = useVerification();

  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="my-16 bg-[#1E1E1E] rounded-xl p-6 border border-[#0066FF]/30 overflow-hidden relative"
    >
      <div className="absolute inset-0 grid-pattern opacity-10"></div>
      
      <h2 className="font-orbitron text-2xl mb-6 relative z-10 text-center md:text-left">
        <span className="text-[#00FF8D]">Interactive</span> ID Verification Simulator
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
        {/* ID Upload Section */}
        <Card className="bg-[#121212] p-5 rounded-lg border border-[#0066FF]/30 glow-border space-y-4">
          <h3 className="font-orbitron text-lg text-[#0066FF]">Step 1: ID Upload</h3>
          
          <FileUpload file={file} setFile={setFile} isUploading={isUploading} />
          
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Shield className="w-4 h-4 text-[#00FF8D] mr-1" />
              <span className="text-xs">Secure encrypted upload</span>
            </div>
            <Button variant="link" size="sm" className="text-xs text-[#FF00AA]">
              Need help?
            </Button>
          </div>
        </Card>
        
        {/* Verification Process */}
        <Card className="bg-[#121212] p-5 rounded-lg border border-[#0066FF]/30 space-y-4 relative">
          <h3 className="font-orbitron text-lg text-[#0066FF]">Step 2: Verification</h3>
          
          <div className="border border-[#0066FF]/30 rounded-lg p-4 h-48 relative flex flex-col justify-center">
            <ScanAnimation isScanning={isVerifying} />
            
            <div className="mt-4 flex justify-between text-xs">
              <span>Verifying authenticity</span>
              <span className="text-[#00FF8D]">{progress}% complete</span>
            </div>
            
            <Progress value={progress} className="w-full bg-[#1E1E1E]/50 h-1 mt-1">
              <div 
                className="bg-[#00FF8D] h-full rounded-full transition-all duration-500 ease-in-out" 
                style={{ width: `${progress}%` }}
              ></div>
            </Progress>
          </div>

          <Button 
            onClick={handleVerify}
            disabled={!file || isVerifying}
            className="w-full bg-[#1E1E1E] hover:bg-[#1E1E1E]/80 border border-[#0066FF] text-[#0066FF]"
          >
            {isVerifying ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Verifying...
              </>
            ) : (
              <>
                <Zap className="mr-2 h-4 w-4" />
                Start Verification
              </>
            )}
          </Button>
        </Card>
        
        {/* Results Display */}
        <Card className="bg-[#121212] p-5 rounded-lg border border-[#0066FF]/30 space-y-4">
          <h3 className="font-orbitron text-lg text-[#0066FF]">Step 3: Results</h3>
          
          <div className="border border-[#0066FF]/30 rounded-lg p-4 h-48 overflow-y-auto relative">
            {!verificationResult ? (
              <div className="absolute inset-0 flex items-center justify-center">
                <p className="text-sm opacity-70">Complete verification to see results</p>
              </div>
            ) : (
              <div>
                <div className="flex justify-between items-center mb-3">
                  <h4 className="font-orbitron text-sm">Verification Score</h4>
                  <span className="text-[#00FF8D] font-orbitron text-lg">{verificationResult.overallScore}%</span>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between bg-[#1E1E1E]/50 p-2 rounded text-xs">
                    <span>Document authenticity</span>
                    <span className="text-[#00FF8D]">{verificationResult.authenticity}%</span>
                  </div>
                  <div className="flex justify-between bg-[#1E1E1E]/50 p-2 rounded text-xs">
                    <span>Security features</span>
                    <span className="text-[#00FF8D]">{verificationResult.securityFeatures}%</span>
                  </div>
                  <div className="flex justify-between bg-[#1E1E1E]/50 p-2 rounded text-xs">
                    <span>Expiration date</span>
                    <span className={verificationResult.expirationStatus ? "text-[#00FF8D]" : "text-[#FF00AA]"}>
                      {verificationResult.expirationStatus ? "Valid" : "Expired"}
                    </span>
                  </div>
                  <div className="flex justify-between bg-[#1E1E1E]/50 p-2 rounded text-xs">
                    <span>Tampering detection</span>
                    <span className={verificationResult.tamperingDetected ? "text-[#FF00AA]" : "text-[#00FF8D]"}>
                      {verificationResult.tamperingDetected ? "Tampering detected" : "No tampering detected"}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <Link href="/verify">
            <a className="block w-full">
              <Button 
                className="w-full py-2 bg-[#1E1E1E] text-[#00FF8D] border border-[#00FF8D] hover:bg-[#00FF8D]/10 transition-colors font-orbitron text-sm"
              >
                Go to Full Verification
              </Button>
            </a>
          </Link>
        </Card>
      </div>
    </motion.section>
  );
};

export default VerificationInterface;
