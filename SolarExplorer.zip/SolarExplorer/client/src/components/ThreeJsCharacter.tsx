import { useEffect, useRef } from "react";
import * as THREE from "three";

const ThreeJsCharacter = () => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Create scene, camera, and renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    const renderer = new THREE.WebGLRenderer({ 
      alpha: true,
      antialias: true 
    });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(window.devicePixelRatio);
    containerRef.current.appendChild(renderer.domElement);

    // Create a futuristic cyber character with more complex geometry
    const createCyberCharacter = () => {
      const group = new THREE.Group();

      // Create a base platform
      const platformGeometry = new THREE.CylinderGeometry(1.5, 1.5, 0.1, 16);
      const platformMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x0d0d20,
        emissive: 0x0066FF,
        emissiveIntensity: 0.2,
        shininess: 30
      });
      const platform = new THREE.Mesh(platformGeometry, platformMaterial);
      platform.position.y = -1.5;
      group.add(platform);
      
      // Add rings to the platform
      const createRing = (radius: number, color: number) => {
        const ringGeometry = new THREE.TorusGeometry(radius, 0.02, 16, 50);
        const ringMaterial = new THREE.MeshBasicMaterial({ 
          color: color,
          transparent: true,
          opacity: 0.7
        });
        const ring = new THREE.Mesh(ringGeometry, ringMaterial);
        ring.rotation.x = Math.PI / 2;
        ring.position.y = -1.45;
        return ring;
      };
      
      const ring1 = createRing(1.2, 0x0066FF);
      const ring2 = createRing(1.0, 0x00FF8D);
      const ring3 = createRing(0.8, 0xFF00AA);
      
      group.add(ring1, ring2, ring3);

      // Create a head using icosahedron (more complex than sphere)
      const headGeometry = new THREE.IcosahedronGeometry(0.8, 1);
      const headMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x0066FF,
        wireframe: true,
        shininess: 100,
        emissive: 0x0066FF,
        emissiveIntensity: 0.3
      });
      const head = new THREE.Mesh(headGeometry, headMaterial);
      head.position.y = 1.2;
      group.add(head);
      
      // Create inner head sphere for glow effect
      const innerHeadGeometry = new THREE.IcosahedronGeometry(0.65, 1);
      const innerHeadMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x0066FF,
        transparent: true,
        opacity: 0.3,
        emissive: 0x0066FF,
        emissiveIntensity: 0.5
      });
      const innerHead = new THREE.Mesh(innerHeadGeometry, innerHeadMaterial);
      innerHead.position.y = 1.2;
      group.add(innerHead);

      // Create a torso using custom geometry
      const torsoGeometry = new THREE.CylinderGeometry(0.4, 0.3, 1.2, 8);
      const torsoMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x00FF8D,
        wireframe: true,
        emissive: 0x00FF8D,
        emissiveIntensity: 0.3
      });
      const torso = new THREE.Mesh(torsoGeometry, torsoMaterial);
      torso.position.y = 0.2;
      group.add(torso);
      
      // Create inner torso for glow effect
      const innerTorsoGeometry = new THREE.CylinderGeometry(0.3, 0.2, 1.1, 8);
      const innerTorsoMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x00FF8D,
        transparent: true,
        opacity: 0.3,
        emissive: 0x00FF8D,
        emissiveIntensity: 0.5
      });
      const innerTorso = new THREE.Mesh(innerTorsoGeometry, innerTorsoMaterial);
      innerTorso.position.y = 0.2;
      group.add(innerTorso);

      // Create a neck
      const neckGeometry = new THREE.CylinderGeometry(0.2, 0.3, 0.3, 16);
      const neckMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x1E1E1E,
        emissive: 0x00FF8D,
        emissiveIntensity: 0.1
      });
      const neck = new THREE.Mesh(neckGeometry, neckMaterial);
      neck.position.y = 0.75;
      group.add(neck);

      // Create arms
      const createArm = (isLeft: boolean) => {
        const armGroup = new THREE.Group();
        
        // Upper arm
        const upperArmGeometry = new THREE.CylinderGeometry(0.1, 0.12, 0.6, 8);
        const upperArmMaterial = new THREE.MeshPhongMaterial({ 
          color: 0x00FF8D,
          wireframe: true,
          emissive: 0x00FF8D,
          emissiveIntensity: 0.3
        });
        const upperArm = new THREE.Mesh(upperArmGeometry, upperArmMaterial);
        upperArm.rotation.z = isLeft ? Math.PI / 4 : -Math.PI / 4;
        upperArm.position.set(isLeft ? -0.3 : 0.3, 0.3, 0);
        armGroup.add(upperArm);
        
        // Forearm
        const forearmGeometry = new THREE.CylinderGeometry(0.08, 0.1, 0.6, 8);
        const forearmMaterial = new THREE.MeshPhongMaterial({ 
          color: 0x00FF8D,
          wireframe: true,
          emissive: 0x00FF8D,
          emissiveIntensity: 0.3
        });
        const forearm = new THREE.Mesh(forearmGeometry, forearmMaterial);
        forearm.position.set(
          isLeft ? -0.6 : 0.6, 
          0.0, 
          0
        );
        forearm.rotation.z = isLeft ? Math.PI / 3 : -Math.PI / 3;
        armGroup.add(forearm);
        
        return armGroup;
      };
      
      const leftArm = createArm(true);
      const rightArm = createArm(false);
      group.add(leftArm, rightArm);

      // Add a halo/ring above the head
      const haloGeometry = new THREE.TorusGeometry(0.5, 0.04, 16, 50);
      const haloMaterial = new THREE.MeshBasicMaterial({ 
        color: 0xFF00AA,
        transparent: true,
        opacity: 0.7
      });
      const halo = new THREE.Mesh(haloGeometry, haloMaterial);
      halo.position.y = 2.2;
      halo.rotation.x = Math.PI / 2;
      group.add(halo);

      // Add data particles around the character
      const particlesGroup = new THREE.Group();
      const particleColors = [0x0066FF, 0x00FF8D, 0xFF00AA];
      
      for (let i = 0; i < 100; i++) {
        const size = 0.03 + Math.random() * 0.05;
        let geometry;
        
        // Create different shapes for particles
        const shapeType = Math.floor(Math.random() * 4);
        
        switch(shapeType) {
          case 0:
            geometry = new THREE.SphereGeometry(size, 8, 8);
            break;
          case 1:
            geometry = new THREE.BoxGeometry(size, size, size);
            break;
          case 2:
            geometry = new THREE.TetrahedronGeometry(size);
            break;
          default:
            geometry = new THREE.OctahedronGeometry(size);
        }
        
        const colorIndex = Math.floor(Math.random() * particleColors.length);
        const particleMaterial = new THREE.MeshBasicMaterial({
          color: particleColors[colorIndex],
          transparent: true,
          opacity: 0.5 + Math.random() * 0.5
        });
        
        const particle = new THREE.Mesh(geometry, particleMaterial);
        
        // Random position in a spherical distribution
        const radius = 2 + Math.random() * 3;
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.random() * Math.PI;
        
        particle.position.x = radius * Math.sin(phi) * Math.cos(theta);
        particle.position.y = radius * Math.sin(phi) * Math.sin(theta) - 0.5; // Center vertically
        particle.position.z = radius * Math.cos(phi);
        
        // Store original position for animation
        (particle as any).originalPos = { ...particle.position };
        (particle as any).speed = 0.005 + Math.random() * 0.015;
        (particle as any).rotationSpeed = 0.01 + Math.random() * 0.02;
        (particle as any).random1 = Math.random() * Math.PI * 2;
        (particle as any).random2 = Math.random() * Math.PI * 2;
        
        particlesGroup.add(particle);
      }
      
      group.add(particlesGroup);

      // Create holographic data streams
      const createDataStream = (startY: number, height: number, color: number) => {
        const streamGroup = new THREE.Group();
        const streamWidth = 0.01;
        
        for (let i = 0; i < 10; i++) {
          const segmentHeight = height / 10;
          const segmentGeometry = new THREE.BoxGeometry(streamWidth, segmentHeight, streamWidth);
          const segmentMaterial = new THREE.MeshBasicMaterial({
            color: color,
            transparent: true,
            opacity: 0.2 + Math.random() * 0.6
          });
          
          const segment = new THREE.Mesh(segmentGeometry, segmentMaterial);
          segment.position.y = startY + i * segmentHeight;
          (segment as any).speed = 0.03 + Math.random() * 0.05;
          (segment as any).originalY = segment.position.y;
          
          streamGroup.add(segment);
        }
        
        return streamGroup;
      };
      
      // Add multiple data streams around the character
      for (let i = 0; i < 5; i++) {
        const angle = (i / 5) * Math.PI * 2;
        const radius = 1.8;
        const streamHeight = 2 + Math.random() * 2;
        const startY = -1.5;
        
        const colorIndex = Math.floor(Math.random() * particleColors.length);
        const stream = createDataStream(startY, streamHeight, particleColors[colorIndex]);
        
        stream.position.x = Math.cos(angle) * radius;
        stream.position.z = Math.sin(angle) * radius;
        
        group.add(stream);
      }

      return { 
        group, 
        particlesGroup, 
        head,
        innerHead,
        torso,
        innerTorso,
        platform,
        leftArm,
        rightArm,
        halo,
        rings: [ring1, ring2, ring3]
      };
    };

    const characterElements = createCyberCharacter();
    const { group, particlesGroup } = characterElements;
    scene.add(group);

    // Add lights for better visualization
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    const pointLight1 = new THREE.PointLight(0x0066FF, 1, 10);
    pointLight1.position.set(3, 3, 3);
    scene.add(pointLight1);
    
    const pointLight2 = new THREE.PointLight(0x00FF8D, 1, 10);
    pointLight2.position.set(-3, 2, -3);
    scene.add(pointLight2);
    
    const pointLight3 = new THREE.PointLight(0xFF00AA, 0.8, 10);
    pointLight3.position.set(0, 4, -2);
    scene.add(pointLight3);

    // Position camera with a slight angle
    camera.position.set(0, 0, 7);
    camera.lookAt(0, 0, 0);

    // Clock for time-based animations
    const clock = new THREE.Clock();

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);
      
      const elapsedTime = clock.getElapsedTime();

      // Rotate the entire character slowly
      group.rotation.y = Math.sin(elapsedTime * 0.2) * 0.5 + elapsedTime * 0.1;
      
      // Animate arms slightly
      characterElements.leftArm.rotation.x = Math.sin(elapsedTime * 0.5) * 0.1;
      characterElements.rightArm.rotation.x = Math.sin(elapsedTime * 0.5 + Math.PI) * 0.1;
      
      // Hovering effect for the character
      group.position.y = Math.sin(elapsedTime * 0.8) * 0.1;
      
      // Rotate rings
      characterElements.rings.forEach((ring, i) => {
        ring.rotation.z = elapsedTime * (0.2 + i * 0.1);
      });
      
      // Pulsate head and torso
      const headPulse = 1 + Math.sin(elapsedTime * 2) * 0.05;
      characterElements.innerHead.scale.set(headPulse, headPulse, headPulse);
      
      const torsoPulse = 1 + Math.sin(elapsedTime * 1.5) * 0.08;
      characterElements.innerTorso.scale.set(torsoPulse, 1, torsoPulse);
      
      // Rotate halo
      characterElements.halo.rotation.z = elapsedTime * 0.3;
      const haloPulse = 1 + Math.sin(elapsedTime * 3) * 0.1;
      characterElements.halo.scale.set(haloPulse, haloPulse, haloPulse);

      // Animate particles with more complex movements
      particlesGroup.children.forEach((particle: any) => {
        const { originalPos, speed, rotationSpeed, random1, random2 } = particle;
        
        // Orbital movement
        particle.position.x = originalPos.x * Math.cos(elapsedTime * speed + random1);
        particle.position.z = originalPos.z * Math.sin(elapsedTime * speed + random1);
        
        // Vertical oscillation
        particle.position.y = originalPos.y + Math.sin(elapsedTime * speed * 2 + random2) * 0.3;
        
        // Rotate particles
        particle.rotation.x = elapsedTime * rotationSpeed;
        particle.rotation.y = elapsedTime * rotationSpeed * 0.8;
      });
      
      // Animate data streams
      group.children.forEach(child => {
        if (child.type === 'Group' && child !== particlesGroup && child !== characterElements.leftArm && child !== characterElements.rightArm) {
          child.children.forEach((segment: any) => {
            if (segment.speed !== undefined) {
              // Move segments upward
              segment.position.y += segment.speed;
              
              // Reset position when reaching the top
              if (segment.position.y > segment.originalY + 5) {
                segment.position.y = segment.originalY;
                segment.material.opacity = 0.2 + Math.random() * 0.6;
              }
            }
          });
        }
      });

      renderer.render(scene, camera);
    };

    animate();

    // Handle window resize
    const handleResize = () => {
      if (!containerRef.current) return;
      camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    // Clean up
    return () => {
      if (containerRef.current && containerRef.current.contains(renderer.domElement)) {
        containerRef.current.removeChild(renderer.domElement);
      }
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return <div ref={containerRef} className="w-full h-full absolute inset-0" />;
};

export default ThreeJsCharacter;
