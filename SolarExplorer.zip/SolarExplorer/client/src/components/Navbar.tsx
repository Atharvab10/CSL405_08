import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu } from "lucide-react";

const Navbar = () => {
  const [location] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navItems = [
    { label: "HOME", path: "/", exact: true },
    { label: "LEARN", path: "/learn" },
    { label: "VERIFY ID", path: "/verify" },
    { label: "RESOURCES", path: "/resources" },
  ];

  const isActive = (itemPath: string, exact = false) => {
    if (exact) return location === itemPath;
    return location.startsWith(itemPath);
  };

  return (
    <nav className="relative z-10 px-4 py-3 bg-[#1E1E1E] bg-opacity-90 backdrop-blur-md border-b border-[#0066FF]/30">
      <div className="container mx-auto flex items-center justify-between">
        <Link href="/">
          <a className="flex items-center">
            <div className="w-10 h-10 mr-2 rounded-full bg-gradient-to-br from-[#0066FF] to-[#00FF8D] flex items-center justify-center">
              <Shield className="w-6 h-6 text-[#121212]" />
            </div>
            <h1 className="font-orbitron text-xl font-bold tracking-wider">
              <span className="text-[#0066FF]">Cyber</span>
              <span className="text-[#00FF8D]">Shield</span>
            </h1>
          </a>
        </Link>
        
        <div className="hidden md:flex space-x-6 items-center">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <a className={`font-orbitron text-sm tracking-wide transition-colors ${
                isActive(item.path, item.exact) 
                  ? "text-[#0066FF] font-semibold" 
                  : "hover:text-[#00FF8D]"
              }`}>
                {item.label}
              </a>
            </Link>
          ))}
        </div>
        
        <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="w-6 h-6 text-[#00FF8D]" />
            </Button>
          </SheetTrigger>
          <SheetContent className="bg-[#1E1E1E] border-l border-[#0066FF]/30">
            <div className="flex flex-col space-y-6 mt-10">
              {navItems.map((item) => (
                <Link key={item.path} href={item.path}>
                  <a 
                    className={`font-orbitron text-lg tracking-wide transition-colors ${
                      isActive(item.path, item.exact) 
                        ? "text-[#0066FF] font-semibold" 
                        : "hover:text-[#00FF8D]"
                    }`}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.label}
                  </a>
                </Link>
              ))}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
};

export default Navbar;
