import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add custom CSS for cybersecurity theme
const style = document.createElement('style');
style.textContent = `
  :root {
    --neon-blue: #0066FF;
    --neon-green: #00FF8D;
    --neon-pink: #FF00AA;
    --dark-bg: #121212;
    --dark-surface: #1E1E1E;
    --off-white: #FAFAFA;
  }

  body {
    background-color: var(--dark-bg);
    background-image: radial-gradient(circle at 50% 50%, #1a1a1a 0%, #121212 100%);
  }

  .font-orbitron {
    font-family: 'Orbitron', sans-serif;
  }

  .font-inter {
    font-family: 'Inter', sans-serif;
  }

  .glow-border {
    box-shadow: 0 0 5px var(--neon-blue), 0 0 10px var(--neon-blue);
    transition: box-shadow 0.3s ease;
  }

  .glow-border:hover {
    box-shadow: 0 0 10px var(--neon-blue), 0 0 20px var(--neon-blue), 0 0 30px var(--neon-blue);
  }

  .glow-text {
    text-shadow: 0 0 5px var(--neon-green), 0 0 10px var(--neon-green);
  }

  .grid-pattern {
    background-image: linear-gradient(rgba(0, 102, 255, 0.1) 1px, transparent 1px), 
                       linear-gradient(90deg, rgba(0, 102, 255, 0.1) 1px, transparent 1px);
    background-size: 20px 20px;
  }

  @keyframes glow {
    0% { box-shadow: 0 0 5px var(--neon-blue), 0 0 10px var(--neon-blue); }
    100% { box-shadow: 0 0 10px var(--neon-blue), 0 0 20px var(--neon-blue), 0 0 30px var(--neon-blue); }
  }

  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-10px); }
  }

  @keyframes scan {
    0% { transform: translateY(0); }
    50% { transform: translateY(100%); }
    100% { transform: translateY(0); }
  }

  .animate-glow {
    animation: glow 2s ease-in-out infinite alternate;
  }

  .animate-float {
    animation: float 6s ease-in-out infinite;
  }

  .scan-line {
    position: absolute;
    height: 2px;
    width: 100%;
    background: linear-gradient(90deg, transparent, var(--neon-green), transparent);
    animation: scan 3s linear infinite;
  }

  .bg-gradient-radial {
    background-image: radial-gradient(circle at 50% 50%, var(--tw-gradient-from) 0%, var(--tw-gradient-to) 100%);
  }
`;
document.head.appendChild(style);

createRoot(document.getElementById("root")!).render(<App />);
