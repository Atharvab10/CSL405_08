import { 
  users, type User, type InsertUser,
  verificationResults, type VerificationResult, type InsertVerificationResult,
  educationalResources, type EducationalResource, type InsertEducationalResource 
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Verification methods
  createVerificationResult(result: InsertVerificationResult): Promise<VerificationResult>;
  getVerificationResult(id: number): Promise<VerificationResult | undefined>;
  getVerificationResultsByUserId(userId: number): Promise<VerificationResult[]>;

  // Educational resources methods
  getEducationalResources(): Promise<EducationalResource[]>;
  getEducationalResourceById(id: number): Promise<EducationalResource | undefined>;
  getEducationalResourcesByCategory(category: string): Promise<EducationalResource[]>;
  createEducationalResource(resource: InsertEducationalResource): Promise<EducationalResource>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private verificationResults: Map<number, VerificationResult>;
  private educationalResources: Map<number, EducationalResource>;
  private userId: number;
  private verificationId: number;
  private resourceId: number;

  constructor() {
    this.users = new Map();
    this.verificationResults = new Map();
    this.educationalResources = new Map();
    this.userId = 1;
    this.verificationId = 1;
    this.resourceId = 1;

    // Initialize with some sample educational resources
    this.seedEducationalResources();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const timestamp = new Date();
    const user: User = { ...insertUser, id, createdAt: timestamp };
    this.users.set(id, user);
    return user;
  }

  // Verification methods
  async createVerificationResult(insertResult: InsertVerificationResult): Promise<VerificationResult> {
    const id = this.verificationId++;
    const timestamp = new Date();
    const result: VerificationResult = { ...insertResult, id, createdAt: timestamp };
    this.verificationResults.set(id, result);
    return result;
  }

  async getVerificationResult(id: number): Promise<VerificationResult | undefined> {
    return this.verificationResults.get(id);
  }

  async getVerificationResultsByUserId(userId: number): Promise<VerificationResult[]> {
    return Array.from(this.verificationResults.values()).filter(
      (result) => result.userId === userId
    );
  }

  // Educational resources methods
  async getEducationalResources(): Promise<EducationalResource[]> {
    return Array.from(this.educationalResources.values());
  }

  async getEducationalResourceById(id: number): Promise<EducationalResource | undefined> {
    return this.educationalResources.get(id);
  }

  async getEducationalResourcesByCategory(category: string): Promise<EducationalResource[]> {
    return Array.from(this.educationalResources.values()).filter(
      (resource) => resource.category === category
    );
  }

  async createEducationalResource(insertResource: InsertEducationalResource): Promise<EducationalResource> {
    const id = this.resourceId++;
    const timestamp = new Date();
    const resource: EducationalResource = { ...insertResource, id, createdAt: timestamp };
    this.educationalResources.set(id, resource);
    return resource;
  }

  private seedEducationalResources() {
    const resources: InsertEducationalResource[] = [
      {
        title: "Common ID Fraud Techniques",
        description: "Learn how criminals attempt to forge identification documents and how modern security features prevent these attacks.",
        category: "fraud-prevention",
        content: "Document tampering detection, Identity theft prevention, Synthetic identity fraud",
        imageUrl: "https://images.unsplash.com/photo-1563013544-824ae1b704d3",
      },
      {
        title: "Modern Security Features",
        description: "Explore the advanced security features built into modern identification documents that make them difficult to counterfeit.",
        category: "security-features",
        content: "Holographic overlays, Microprinting technology, UV and IR reactive elements",
        imageUrl: "https://images.unsplash.com/photo-1562813733-b31f0941fd52",
      },
      {
        title: "Biometric Verification",
        description: "Understand how biometric technologies are revolutionizing identity verification beyond physical documents.",
        category: "biometrics",
        content: "Facial recognition systems, Fingerprint authentication, Liveness detection technology",
        imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b",
      }
    ];

    resources.forEach(resource => {
      const id = this.resourceId++;
      const timestamp = new Date();
      const fullResource: EducationalResource = { ...resource, id, createdAt: timestamp };
      this.educationalResources.set(id, fullResource);
    });
  }
}

export const storage = new MemStorage();
