import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertVerificationResultSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { z } from "zod";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (_req, file, cb) => {
    const allowedMimeTypes = ["image/jpeg", "image/png"];
    if (allowedMimeTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Only JPEG and PNG files are allowed"));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all educational resources
  app.get("/api/resources", async (_req: Request, res: Response) => {
    try {
      const resources = await storage.getEducationalResources();
      res.json(resources);
    } catch (error) {
      console.error("Error getting resources:", error);
      res.status(500).json({ message: "Failed to get educational resources" });
    }
  });

  // Get educational resources by category
  app.get("/api/resources/category/:category", async (req: Request, res: Response) => {
    try {
      const { category } = req.params;
      const resources = await storage.getEducationalResourcesByCategory(category);
      res.json(resources);
    } catch (error) {
      console.error("Error getting resources by category:", error);
      res.status(500).json({ message: "Failed to get educational resources" });
    }
  });

  // Get a specific educational resource
  app.get("/api/resources/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid resource ID" });
      }
      
      const resource = await storage.getEducationalResourceById(id);
      if (!resource) {
        return res.status(404).json({ message: "Resource not found" });
      }
      
      res.json(resource);
    } catch (error) {
      console.error("Error getting resource:", error);
      res.status(500).json({ message: "Failed to get resource" });
    }
  });

  // Simulate ID verification
  app.post("/api/verify", upload.single("idImage"), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { documentType = "generic-id" } = req.body;

      // In a real application, we would analyze the image here
      // For this simulation, we'll generate random verification scores
      const simulateVerification = () => {
        const generateScore = () => Math.floor(Math.random() * 40) + 60; // Generate scores between 60-99
        
        const authenticityScore = generateScore();
        const securityFeaturesScore = generateScore();
        const expirationStatus = Math.random() > 0.2; // 80% chance of being valid
        const tamperingDetected = Math.random() < 0.2; // 20% chance of detecting tampering
        
        // Calculate overall score based on other factors
        const overallScore = Math.floor(
          (authenticityScore * 0.4) +
          (securityFeaturesScore * 0.4) +
          (expirationStatus ? 10 : 0) +
          (tamperingDetected ? 0 : 10)
        );
        
        return {
          documentType,
          fileName: req.file!.originalname,
          mimeType: req.file!.mimetype,
          fileSize: req.file!.size,
          authenticity: authenticityScore,
          securityFeatures: securityFeaturesScore,
          expirationStatus,
          tamperingDetected,
          overallScore,
          userId: 1, // In a real app, this would be the authenticated user's ID
          details: {
            processingTime: `${Math.floor(Math.random() * 2) + 1}.${Math.floor(Math.random() * 9)}s`,
            additionalChecks: {
              dataIntegrity: Math.random() > 0.3,
              microprinting: Math.random() > 0.3,
              uvFeatures: Math.random() > 0.3,
            }
          }
        };
      };

      // Generate verification data
      const verificationData = simulateVerification();
      
      // Parse and validate the generated data
      try {
        const validatedData = insertVerificationResultSchema.parse(verificationData);
        const result = await storage.createVerificationResult(validatedData);
        
        // Add a small delay to simulate processing time
        setTimeout(() => {
          res.status(201).json(result);
        }, 2000);
      } catch (validationError) {
        if (validationError instanceof z.ZodError) {
          const readableError = fromZodError(validationError);
          res.status(400).json({ message: readableError.message });
        } else {
          throw validationError;
        }
      }
    } catch (error) {
      console.error("Error during verification:", error);
      res.status(500).json({ message: "Verification process failed" });
    }
  });

  // Get verification results for a user
  app.get("/api/verification-results/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const results = await storage.getVerificationResultsByUserId(userId);
      res.json(results);
    } catch (error) {
      console.error("Error getting verification results:", error);
      res.status(500).json({ message: "Failed to get verification results" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
